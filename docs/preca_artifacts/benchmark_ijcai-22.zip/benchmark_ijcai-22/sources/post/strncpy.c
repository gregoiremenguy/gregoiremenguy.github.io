#include <assert.h>
#include <string.h>


char *
libc_strncpy(char *dst, const char *src, size_t n)
{
	if (n != 0) {
		char *d = dst;
		const char *s = src;
		do {
			if ((*d++ = *s++) == 0) {
				/* NUL pad the remaining n-1 bytes */
				while (--n != 0)
					*d++ = 0;
				break;
			}
		} while (--n != 0);
	}
        assert(dst != NULL);
	return (dst);
}

int main() {
    libc_strncpy(NULL, NULL, 0);
    return 0;
}
