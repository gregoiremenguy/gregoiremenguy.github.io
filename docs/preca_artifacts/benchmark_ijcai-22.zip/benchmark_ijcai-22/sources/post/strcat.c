#include <assert.h>
#include <stdlib.h>

char *
libc_strcat(char *s, const char *append)
{
	char *save = s;
	for (; *s; ++s);
	while ((*s++ = *append++) != '\0');
        assert(save != NULL);
	return(save);
}

int main() {
    libc_strcat(NULL, NULL);
    return 0;
}
