#include <assert.h>
#include <string.h>

/* Compare S1 and S2, returning less than, equal to or
   greater than zero if S1 is lexicographically less than,
   equal to or greater than S2.  */
int
fun_strcmp(const char *p1, const char *p2)
{
  const unsigned char *s1 = (const unsigned char *) p1;
  const unsigned char *s2 = (const unsigned char *) p2;
  unsigned char c1, c2;
  do
    {
      c1 = (unsigned char) *s1++;
      c2 = (unsigned char) *s2++;
      if (c1 == '\0')
        return c1 - c2;
    }
  while (c1 == c2);
  return c1 - c2;
}

int glibc_strcmp(const char *p1, const char *p2) {
    int res = fun_strcmp(p1, p2);
    assert(res == 0);
    return res;
}

int main() {
    glibc_strcmp(NULL, NULL);
    return 0;
}
