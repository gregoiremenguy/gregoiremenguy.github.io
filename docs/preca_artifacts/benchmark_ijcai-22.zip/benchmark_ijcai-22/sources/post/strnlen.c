#include <assert.h>
#include <string.h>

size_t
strnlen (const char *s, size_t maxlen)
{
  size_t i;
  for (i = 0; i < maxlen; ++i)
    if (s[i] == '\0')
      break;
  assert(i != 0);
  return i;
}

int main() {
    int a = 0;
    char str[] = "lala";
    a += strnlen(str, 0);
    return 0;
}
