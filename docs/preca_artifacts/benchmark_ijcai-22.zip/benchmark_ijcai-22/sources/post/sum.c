#include <assert.h>
#include <stdlib.h>

/*
 * I think the good invariant is:
 * n >= 0 /\ [ n != 0 => valid(arr) ] /\ [ n != 0 => len(arr) >= n ]
 */
int sum(int * arr, int n) {
    int s = 0;
    int i = 0;
    while (i != n) {
        s = s + arr[i];
        i++;
    }
    assert(s!=0);
    return s;
}

int main() {
    sum(NULL, 0);
    return 0;
}
