#include <assert.h>
#include <stdlib.h>

char *
libc_strcpy(char *to, const char *from)
{
	char *save = to;
	for (; (*to = *from) != '\0'; ++from, ++to);
        assert(save != NULL);
	return(save);
}


int main() {
    libc_strcpy(NULL, NULL);
    return 0;
}
