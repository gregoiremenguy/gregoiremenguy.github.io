#include <assert.h>
#include <string.h>

size_t
libc_strcspn(const char* s1, const char *s2)
{
	const char *p, *spanp;
	char c, sc;

	/*
	 * Stop as soon as we find any character from s2.  Note that there
	 * must be a NUL in s2; it suffices to stop when we find that, too.
	 */
	for (p = s1;;) {
		c = *p++;
		spanp = s2;
		do {
			if ((sc = *spanp++) == c)
				return (p - 1 - s1);
		} while (sc != 0);
	}
	/* NOTREACHED */
}


char *
libc_strpbrk(const char *s, const char *accept)
{
  s += libc_strcspn (s, accept);
  if (*s) {
      return (char*) s;
  }
  else {
      assert(0);
      return NULL;
  }
}

int main() {
    libc_strpbrk(NULL, NULL);
    return 0;
}
