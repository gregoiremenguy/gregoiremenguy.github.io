#include <stdlib.h>
#include <assert.h>

/*
 * Code inspired from : https://github.com/sosy-lab/sv-benchmarks/blob/master/c/array-cav19/array_init_pair_symmetr.c
 * Verification competition of CAV19
 */

#define __VERIFIER_nondet_int() rand()
#define __VERIFIER_assert(b) assert(b)

void assume_abort_if_not(int boolean) {
    assert(boolean);
}

void foo(int* a, int* b, int* c, int N) { 
    int i;
    for(i=0;i<N;i++) {
        int x=__VERIFIER_nondet_int();
        assume_abort_if_not(x > -100000 && x < 100000);
        a[i]=x;
        b[i]=-x;
    }

    for(i=0;i<N;i++){
        c[i]=a[i]+b[i];
    }

    for(i=0;i<N;i++)
        __VERIFIER_assert(c[i] == 0);

}

int main() {
    foo(NULL, NULL, NULL, 0);
    return EXIT_SUCCESS;
}
