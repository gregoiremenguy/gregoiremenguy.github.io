#include <assert.h>

int rec(int first, int second) {
    return second == 0 ? first : rec(second, first % second);
}

int gcd(int first, int second) {
    int res = rec(first, second);
    assert(res != 0);
    return res;
}

int main() {
    gcd(0, 0);
    return 0;
}
