#include <assert.h>

int fact(int n) {
    assert(n >= 0);
    int res = 1;
    int i;
    for (i=1; i<n; i++) {
        res *= i;
    }
    assert(res != 0);
    return res;
}

int main() {
    fact(0);
    return 0;
}
