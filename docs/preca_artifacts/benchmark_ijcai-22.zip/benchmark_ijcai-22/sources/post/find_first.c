#include <assert.h>
#include <stdlib.h>
// From https://github.com/lyonel2017/Frama-C-WP-Examples/blob/master/find_first/find_first.c

// [ n > 0 => valid(t) ]
int find(int * t, int n, int val){
	int i = 0;
	
	for(i = 0; i < n; i++){
		if(t[i] == val){
			return i;		
		}
	}
	return n;
}

// [ m > 0 => valid(a) ] /\ [m > 0 /\ n > 0 => valid(b) ]
int find_first_of(int *a, int m, int *b, int n){
  for(int i = 0; i < m; i++){
    if(find(b, n, a[i]) < n){
      assert(i < m);
      return i;
    }
  }
  assert(0);
  return m;
}

int main() {
    find_first_of(NULL, 0, NULL, 0);
    return 0;
}
