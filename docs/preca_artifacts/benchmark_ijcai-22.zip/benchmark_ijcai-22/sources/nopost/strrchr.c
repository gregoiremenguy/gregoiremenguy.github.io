#include <stdlib.h>

char *
libc_strrchr (const char *s, int c)
{
  char *rtnval = 0;
  do {
    if (*s == c)
      rtnval = (char*) s;
  } while (*s++);
  return (rtnval);
}

int main() {
    libc_strrchr(NULL, 0);
    return 0;
}
