#include <stdlib.h>
#include <stdbool.h>

#define MAXSTR 100
#define MAXPAT MAXSTR
#define CLOSIZE 1
#define CLOSURE '*'

int addstr(char c, char* outset, int *j , int maxset) {
    bool result;
    if (*j >= maxset) {
        result = false;
    }
    else {
        outset[*j] = c;
        *j = *j + 1;
        result = true;
    }
    return result;
}

// valid(pat) /\ valid(j) /\ size(pat) >= lastj /\ size(pat) >= *j
void stclose(char* pat, int* j , int lastj) {
    int jt;
    int jp;
    bool junk;

    for (jp = *j -1; jp >= lastj; jp--) {
        jt = jp + CLOSIZE;
        junk = addstr(pat[jp], pat, &jt, MAXPAT);
    }

    *j = *j + CLOSIZE;
    pat[lastj] = CLOSURE;
}

int main() {
    stclose(NULL, NULL, 0);
    return 0;
}
