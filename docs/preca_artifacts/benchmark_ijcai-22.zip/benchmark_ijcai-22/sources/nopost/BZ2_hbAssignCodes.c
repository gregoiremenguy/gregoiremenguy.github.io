#include <stdint.h>

void BZ2_hbAssignCodes ( int32_t *code, 
                         unsigned char *length,
                         int32_t minLen,
                         int32_t maxLen,
                         int32_t alphaSize )
{
   int32_t n, vec, i;

   vec = 0;
   for (n = minLen; n <= maxLen; n++) {
      for (i = 0; i < alphaSize; i++) {
         if (length[i] == n) { 
             code[i] = vec; vec++; 
         }
      }
      vec <<= 1;
   }
}


int main() {
    BZ2_hbAssignCodes(0, 0, 0, 0, 0);
    return 0;
}
