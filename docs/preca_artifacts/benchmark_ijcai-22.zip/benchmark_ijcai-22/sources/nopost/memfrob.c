#include <string.h>
void *
glibc_memfrob (void *s, size_t n)
{
  char *p = (char *) s;
  while (n-- > 0)
    *p++ ^= 42;
  return s;
}

int main() {
    glibc_memfrob(NULL, 0);
    return 0;
}
