#include <stdlib.h>

/*
 * I think the good invariant is:
 * valid(x)
 * */
int inc(int* x, int y) {
    *x += y;
    return *x;
}

int main() {
    inc(NULL, 0);
    return 0;
}
