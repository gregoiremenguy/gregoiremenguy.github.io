
#include <stdint.h>


#define mswap(zz1, zz2) \
   { int32_t zztmp = zz1; zz1 = zz2; zz2 = zztmp; }

void mvswap(uint32_t* ptr, int32_t zzp1, int32_t zzp2, int32_t zzn)
{                                     
   int32_t yyp1 = (zzp1);
   int32_t yyp2 = (zzp2);
   int32_t yyn  = (zzn);
   while (yyn > 0) {
      mswap(ptr[yyp1], ptr[yyp2]);
      yyp1++; yyp2++; yyn--;
   }
}

int main() {
    mvswap(0, 0, 0, 0);
    return 0;
}
