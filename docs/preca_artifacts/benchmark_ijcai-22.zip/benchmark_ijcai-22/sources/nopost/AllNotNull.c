#include <string.h>

typedef struct _Ptr {
    void* f;
} Ptr;


void AllNotNull(Ptr A[], size_t len) {
    size_t i = 0;
    while (i<len) {
        A[i].f = (void*)0x1;
        i++;
    }
}

int main() {
    AllNotNull(NULL, 0);
    return 0;
}
