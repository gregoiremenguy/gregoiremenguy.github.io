#include <assert.h>
#include <stdlib.h>

int fibo(int n) {
    assert(n >= 0);
    switch (n) {
        case 0:
            return 0;
        case 1:
            return 1;
        default: {
            int* fibs = malloc((n+1)*sizeof(int));
            fibs[0] = 0;
            fibs[1] = 1;
            for (int i = 2; i <= n; i++) {
                fibs[i] = fibs[i-2] + fibs[i-1];
            }
            return fibs[n];
        }
    }

}

int main() {
    fibo(0);
    return 0;
}
