#include <string.h>

void *
libc_memcpy (void *dest, const void *src, size_t len)
{
  char *d = dest;
  const char *s = src;
  while (len--)
    *d++ = *s++;
  return dest;
}

int main() {
    libc_memcpy(NULL, NULL, 0);
    return 0;
    
}
