
int gcd(int first, int second) {
    return second == 0 ? first : gcd(second, first % second);
}

int main() {
    gcd(0, 0);
    return 0;
}
