#include <string.h>

void *
libc_memccpy(void* t, const void* f, int c, size_t n)
{

	if (n) {
		unsigned char *tp = t;
		const unsigned char *fp = f;
		do {
			if ((*tp++ = *fp++) == c)
				return (t);
		} while (--n != 0);
	}
	return (0);
}

int main() {
    libc_memccpy(NULL, NULL, 0, 0);
}
