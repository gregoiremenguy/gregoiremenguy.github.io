#include <assert.h>

int power(int baseNumber, int exponent) {
    assert(exponent >= 0);
    if (exponent == 0)
    {
        return 1; // n^0 = 1
    }

    int power = baseNumber;
    while (exponent > 1)
    {
        power *= baseNumber;
        exponent--;
    }

    return power;
}


int maxvalue(int numberBase, int digits) {
    return power(numberBase, digits) - 1;
}


int main() {
    maxvalue(0, 0);
    return 0;
}
