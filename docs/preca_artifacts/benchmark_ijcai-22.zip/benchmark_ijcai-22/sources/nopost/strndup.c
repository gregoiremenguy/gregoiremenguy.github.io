#include <stdlib.h>
#include <string.h>

size_t
libc_strnlen (const char *s, size_t maxlen)
{
  size_t i;
  for (i = 0; i < maxlen; ++i)
    if (s[i] == '\0')
      break;
  return i;
}

void *
libc_memcpy (void *dest, const void *src, size_t len)
{
  char *d = dest;
  const char *s = src;
  while (len--)
    *d++ = *s++;
  return dest;
}


char *
glibc_strndup (const char *s, size_t n)
{
  size_t len = libc_strnlen (s, n);
  char *new = (char *) malloc (len + 1);
  if (new == NULL)
    return NULL;
  new[len] = '\0';
  return (char *) libc_memcpy (new, s, len);
}


int main() {
    glibc_strndup(NULL, 0);
    return 0;
}
