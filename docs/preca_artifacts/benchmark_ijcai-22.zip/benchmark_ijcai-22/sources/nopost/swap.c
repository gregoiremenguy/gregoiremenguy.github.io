#include <stdlib.h>

// WARINING : Found in Science of Programming but not in the Daikon paper

/*
 * I think that the good invariant is:
 * valid(x) /\ valid(y)
 */
void swap(int* x, int* y) {
    int tmp = *x;
    *x = *y;
    *y = tmp;
}

int main() {
    swap(NULL, NULL);
    return 0;
}
